script_info = {
	["title"] = "删除中间字符串",
	["description"] = "",
	["version"] = "0.0.1",
	["tooltip"] = "",
	["edit_count"] = "2",
	["edit_tips"] = "开头;结尾",
}

--[[
	重命名函数
	参数:
		file 文件信息
			file.name	文件名
			file.id		文件id
			file.path	文件路径
			file.size	文件大小
			file.mtime	文件修改时间
			file.isdir	是否为目录
		input 用户输入
	返回值:
		新文件名
--]]
function onRename(file, input)
	local i, _ = string.find(file.name, input[1], 1, true)
	local _, j = string.find(file.name, input[2], 1, true)
	if i then
		file.name = string.sub(file.name, 1, i - 1) .. string.sub(file.name, j + 1)
	end
	return file.name
end