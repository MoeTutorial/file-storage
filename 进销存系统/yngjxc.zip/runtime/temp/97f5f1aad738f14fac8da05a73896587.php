<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:57:"/www/wwwroot/js-movie/public/../app/view/index/index.html";i:1691506456;s:40:"/www/wwwroot/js-movie/app/view/base.html";i:1691505759;s:52:"/www/wwwroot/js-movie/app/view/public/menu_base.html";i:1598613970;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Xenon Boostrap Admin Panel" />
    <meta name="author" content="" />

    <title>仓库管理</title>

    <link rel="stylesheet" href="/static/css/fonts/linecons/css/linecons.css">
    <link rel="stylesheet" href="/static/css/fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="/static/css/bootstrap.css">
    <link rel="stylesheet" href="/static/css/xenon-core.css">
    <link rel="stylesheet" href="/static/css/xenon-forms.css">
    <link rel="stylesheet" href="/static/css/xenon-components.css">
    <link rel="stylesheet" href="/static/css/xenon-skins.css">
    <link rel="stylesheet" href="/static/css/custom.css">
    <!-- toast -->
    <link rel="stylesheet" type="text/css" href="/static/js/toastr/toastr.css" />
    
    <script src="/static/js/jquery-1.11.1.min.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>

<body class="page-body">
    <div class="page-container">
        <!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->

        <!-- Add "fixed" class to make the sidebar fixed always to the browser viewport. -->
        <!-- Adding class "toggle-others" will keep only one menu item open at a time. -->
        <!-- Adding class "collapsed" collapse sidebar root elements and show only icons. -->
        <div class="sidebar-menu toggle-others fixed">

            <div class="sidebar-menu-inner">

                <header class="logo-env">
                    <!-- logo -->
                    <div class="logo">
                        <a href="#" class="logo-expanded">
                            <img src="/static/images/logo.png" width="120" alt="logo" />
                        </a>
                    </div>
                </header>
                <!-- 菜单 -->
                <ul id="main-menu" class="main-menu">
	<?php if(is_array($_menuList) || $_menuList instanceof \think\Collection || $_menuList instanceof \think\Paginator): $i = 0; $__LIST__ = $_menuList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
	<li>
		<a href="<?php echo url($vo['controller'].'/'.$vo['action']); ?>">
			<i class="<?php echo $vo['ico']; ?>"></i>
			<span class="title"><?php echo $vo['name']; ?></span>
		</a>
		<?php if($vo['child']): ?>
		<ul>
			<?php if(is_array($vo['child']) || $vo['child'] instanceof \think\Collection || $vo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
			<li class=" <?php echo $vv['controller']; ?>-<?php echo $vv['action']; ?>">
				<a href="<?php echo url($vv['controller'].'/'.$vv['action']); ?>"><span class="title"><?php echo $vv['name']; ?></span></a>
			</li>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</ul>
		<?php endif; ?>

	</li>
	<?php endforeach; endif; else: echo "" ;endif; ?>

</ul>


<script>
	function nav_show($cn) {
		var className = $cn || '<?php echo \think\Request::instance()->controller(); ?>-<?php echo \think\Request::instance()->action(); ?>';
		$("." + className).addClass('active');
		$("." + className).parent().parent().addClass('active open');
		$("." + className).parent().show();
	}
</script>

            </div>

        </div>


        <div class="main-content">

            <!-- User Info, Notifications and Menu Bar -->
            <nav class="navbar user-info-navbar" role="navigation">
                <!-- Right links for user info navbar -->
                <ul class="user-info-menu right-links list-inline list-unstyled">
                    <!-- You can add "always-visible" to show make the search input visible -->
                    <li class="dropdown user-profile">
                        <a href="#" data-toggle="dropdown">
                            <img src="/static/images/user-4.png" alt="user-image"
                                class="img-circle img-inline userpic-32" width="28" />
                            <span>
                                <?php echo $my_info->truename; ?>
                                <i class="fa-angle-down"></i>
                            </span>
                        </a>

                        <ul class="dropdown-menu user-profile-menu list-unstyled">
                            <!-- 							<li>
								<a href="#edit-profile">
									<i class="fa-edit"></i>
									新的岗位
								</a>
							</li> -->
                            <!-- <li>
                                <a href="#settings">
                                    <i class="fa-wrench"></i>
                                    设置
                                </a>
                            </li>
                            <li>
                                <a href="#profile">
                                    <i class="fa-user"></i>
                                    资料
                                </a>
                            </li>
                            <li>
                                <a href="#help">
                                    <i class="fa-info"></i>
                                    帮助
                                </a>
                            </li> -->
                            <li class="last">
                                <a href="<?php echo url('Login/quit'); ?>">
                                    <i class="fa-lock"></i>
                                    注销
                                </a>
                            </li>
                        </ul>
                    </li>
                    <!-- 					<li>
						<a href="#" data-toggle="chat">
							<i class="fa-comments-o"></i>
						</a>
					</li> -->
                </ul>
            </nav>
            <script>
                jQuery(document).ready(function ($) {
                    $('a[href="#layout-variants"]').on('click', function (ev) {
                        ev.preventDefault();
                        var win = { top: $(window).scrollTop(), toTop: $("#layout-variants").offset().top - 15 };
                        TweenLite.to(win, .3, {
                            top: win.toTop, roundProps: ["top"], ease: Sine.easeInOut, onUpdate: function () {
                                $(window).scrollTop(win.top);
                            }
                        });
                    });
                });
            </script>

            
<!-- main -->
<div class="jumbotron">

	<h1>欢迎使用：岩码阁 进销存系统</h1>
	
	<!-- <div class="row">
	    <div class="col-md-12">
	        <div class="panel panel-default">
	            
	        </div>
	    </div>
	</div> -->
	
</div>
<!-- main -->	


            <!-- Main Footer -->
            <!-- Choose between footer styles: "footer-type-1" or "footer-type-2" -->
            <!-- Add class "sticky" to  always stick the footer to the end of page (if page contents is small) -->
            <!-- Or class "fixed" to  always fix the footer to the end of page -->
            <footer class="main-footer sticky footer-type-1">
                <div class="footer-inner">
                    <!-- Add your copyright text here -->
                    <div class="footer-text">
                        &copy; 2020 - 2023 <strong>SANYIMOE</strong> Inc.
                    </div>
                    <!-- Go to Top Link, just add rel="go-top" to any link to add this functionality -->
                    <div class="go-up">
                        <a href="#" rel="go-top">
                            <i class="fa-angle-up"></i>
                        </a>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <!-- Bottom Scripts -->
    <script src="/static/js/bootstrap.min.js"></script>
    <script src="/static/js/TweenMax.min.js"></script>
    <script src="/static/js/resizeable.js"></script>
    <script src="/static/js/joinable.js"></script>
    <script src="/static/js/xenon-api.js"></script>
    <script src="/static/js/xenon-toggles.js"></script>
    <script src="/static/js/toastr/toastr.js"></script>
    <script src="/static/js/datatables/js/jquery.dataTables.min.js"></script>
    
    <!-- JavaScripts initializations and stuff -->
    <script src="/static/js/xenon-custom.js"></script>
</body>
</html>