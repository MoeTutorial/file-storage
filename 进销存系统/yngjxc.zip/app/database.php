<?php return array (
  'type' => 'mysql',
  'hostname' => 'localhost',
  'database' => 'wms',
  'username' => 'wms',
  'password' => 'baKyAWP2MEr4b2nW',
  'hostport' => '3306',
  'dsn' => '',
  'params' => 
  array (
  ),
  'charset' => 'utf8',
  'prefix' => 'w_',
  'debug' => true,
  'deploy' => 0,
  'rw_separate' => false,
  'master_num' => 1,
  'slave_no' => '',
  'fields_strict' => true,
  'resultset_type' => 'array',
  'auto_timestamp' => false,
  'datetime_format' => 'Y-m-d H:i:s',
  'sql_explain' => false,
);