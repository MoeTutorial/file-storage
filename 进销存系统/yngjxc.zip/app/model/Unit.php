<?php
namespace app\model;
use think\Model;

class Unit extends Model
{
	protected $pk = 'id';
}

