<?php
namespace app\model;
use think\Model;

class Supplier extends Model
{
	protected $pk = 'id';
	// protected $table = 'think_user';
}

