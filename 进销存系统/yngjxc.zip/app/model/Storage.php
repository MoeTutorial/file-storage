<?php
namespace app\model;
use think\Model;

class Storage extends Model
{
	protected $pk = 'id';

}

