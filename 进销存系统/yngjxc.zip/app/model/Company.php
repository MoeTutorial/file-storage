<?php
namespace app\model;
use think\Model;

class Company extends Model
{
	protected $pk = 'id';
}
