<?php
namespace app\model;
use think\Model;

class Productup extends Model
{
	protected $pk = 'id';
}

