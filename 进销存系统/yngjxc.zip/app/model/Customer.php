<?php
namespace app\model;
use think\Model;

class Customer extends Model
{
	protected $pk = 'id';
}

